﻿/*************************************************************************
 * Use of try-catch-throw statement. Program will throw new exeptions i.e
 * user definied exceptione. If the user enters guess smaller then 1 and
 * greater then 10 program will throw respective excption.
 * In this program I am not catching these exceptions. 
 * 
 * syntex:
 * throw new Exceptoin("message to user");
 * 
 * Author: Salar Asker Zada                      
 *************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThrowNewException
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        Image imgWin = Image.FromFile("win.gif");
        Image imgBalck = Image.FromFile("black.gif");
        Image imgWhite = Image.FromFile("white.gif");
        int ban = 0;

        private void btnCheck_Click(object sender, EventArgs e)
        {
           
            lblComputer.Text = RandomFunction().ToString();
            int? yourGuess=null;
            bool control = true;
            try
            {
                yourGuess = int.Parse(tbxGuess.Text);
            }
            catch(FormatException ee)
            {
                MessageBox.Show("1. Entery field is empty or\n" +
                                "2. Having wrong formate!", "Input Error");
                  tbxGuess.Text = "";
                  tbxGuess.Focus();
                control = !control;

            }
            
           

            if (yourGuess < 5 )
            {  
                throw new Exception("Value must be bigger then 1"); //exception throw
                control = !control;
            }
            if (yourGuess > 10)
            {
                throw new Exception("Value must be smaller then 10"); //exception throw
                control = !control;
            }

                if (control == true && yourGuess != int.Parse(lblComputer.Text))
                {
                    lblComputer.Image = imgWhite;
                    lblComputer.Text = lblComputer.Text;
                    MessageBox.Show("Wrong Guess :(!", "Guess Result");
                    //Reset
                    lblComputer.Image = imgBalck;
                    
                }
                if (control == true && yourGuess == int.Parse(lblComputer.Text))
                {

                    lblComputer.Image = imgWin;
                    lblComputer.Text = lblComputer.Text;
                    MessageBox.Show("You Guessed Right!", "Guess Result");

                    //Reset
                    lblComputer.Image = imgBalck;
                    tbxGuess.Text = "";
                    tbxGuess.Focus();
                }

}

    private void Form1_Load(object sender, EventArgs e)
        {
            lblComputer.Image = imgBalck;
        }
        private void btnAgain_Click(object sender, EventArgs e)
        {
            lblComputer.BackColor = Color.Black;

        }
        //Class Scope

        private static int RandomFunction()
        {
            int computerGuess;
            Random nr = new Random();
            computerGuess = nr.Next(5, 11);
            return computerGuess;
        }
    }
}
