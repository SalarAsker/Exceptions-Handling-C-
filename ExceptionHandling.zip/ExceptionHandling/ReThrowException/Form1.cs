﻿/*************************************************************************
 * Use of try-catch-throw statement. Program will rethrow the exeption being
 * catch earlier. Sometimes in software development vi are in situation where 
 * we catch en exception and want to propogate it uppwards for higher level. 
 * There can be several reason to rethrow exception, for exempel, 
 * I want to log the exception and free system resources but still want the program
 * to exit from it. 
 * In the following program you see that if FormatException takes place in tbxGuess.Text
 * so it catches in catch block where program performs som necessory jobs like free 
 * resources and a warning to user. Exception rethrow from cath and being cathces by
 * another catch block which do som others necessory measures like if it happens three
 * times so user vill not be able to run the program.
 * 
 * syntex
 * try
 * {
 * 
 * }catch
 *      {
 *          //do some
 *          
 *          try
 *          {
 *              throw; //throw again
 *              
 *          }catch
 *               {
 *                  //do some more
 *               }
 *         
 *      }
 * 
 *  * 
 * Author: Salar Asker Zada                      
 *************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReThrowException
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Image imgWin = Image.FromFile("win.gif");
        Image imgBalck = Image.FromFile("black.gif");
        Image imgWhite = Image.FromFile("white.gif");
        int ban = 0;
        private void btnCheck_Click(object sender, EventArgs e)
        {
            //getting a random int 5-10
            lblComputer.Text = RandomFunction().ToString();
            int? yourGuess = null;
            bool control = true;
            try
            {
                yourGuess = int.Parse(tbxGuess.Text);
            }
            catch (FormatException)// catchning for the first time and dealing with it
            {
                MessageBox.Show("1. Entery field is empty or\n" +
                                "2. Having wrong formate!", "Input Error");
                tbxGuess.Text = "";
                tbxGuess.Focus();
                control = !control;

                try
                {
                    throw;//rethrowing 
                }
                catch //catching it again and doing som more stuff
                {
                    ban++;
                    MessageBox.Show("This field can't be empty!\n" +
                        "warning " + ban.ToString());
                    if (ban == 3)
                    {
                        btnCheck.Enabled = false;
                        MessageBox.Show("You got "+ ban.ToString() +" warning\n" +
                            "Program is lock" );
                    }
                        

                }

            }



            if (yourGuess < 5)
            {
                throw new Exception("Value must be bigger then 1"); //exception throw
                control = !control;
            }
            if (yourGuess > 10)
            {
                throw new Exception("Value must be smaller then 10"); //exception throw
                control = !control;
            }

            if (control == true && yourGuess != int.Parse(lblComputer.Text))
            {
                lblComputer.Image = imgWhite;
                lblComputer.Text = lblComputer.Text;
                MessageBox.Show("Wrong Guess :(!", "Guess Result");
                //Reset
                lblComputer.Image = imgBalck;

            }
            if (control == true && yourGuess == int.Parse(lblComputer.Text))
            {

                lblComputer.Image = imgWin;
                lblComputer.Text = lblComputer.Text;
                MessageBox.Show("You Guessed Right!", "Guess Result");

                //Reset
                lblComputer.Image = imgBalck;
                tbxGuess.Text = "";
                tbxGuess.Focus();
            }

        }
        //Class Scope

        private static int RandomFunction()
        {
            int computerGuess;
            Random nr = new Random();
            computerGuess = nr.Next(5, 11);
            return computerGuess;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblComputer.Image = imgBalck;
        }
    }
}
