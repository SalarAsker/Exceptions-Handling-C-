﻿/*************************************************
 * Use of try-catch statement. Program can catch *
 * Format and OverFlow exceptions.               *
 *                                               *
 * Author: Salar Asker Zada                      *
 *************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TryCatchSimple
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double monthlyInvestment = 0;
            try
            {
                monthlyInvestment = double.Parse(tbxMonthlyInvestment.Text);
            }
            catch
            {
                MessageBox.Show("Invalid data supplied to Monthly Investment");
            }

            double yearlyIntrestRate = double.Parse(tbxYearlyInterestRate.Text);
            int noOfYears = int.Parse(tbxNumberOfYears.Text);
            double monthlyInterestRate = yearlyIntrestRate / 12 / 100;
            int months = noOfYears * 12;
            double futureValue = 0;

            for (int i = 0; i < months; i++)
            {
                futureValue = ((futureValue + monthlyInvestment)
                    * (1 + monthlyInterestRate));
            }

            tbxFutureValue.Text = Math.Round(futureValue,2).ToString("c");
           
        }
    }
}
