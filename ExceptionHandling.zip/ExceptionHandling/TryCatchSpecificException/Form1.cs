﻿
/*************************************************
 * Use of try-catch statement. Program can catch 
 * specific types of exeception.The most specific                
 * type of exceptions in a class hierarchy codes                                               
 * first(see exceptions class hierarchy) and least
 * specific exceptions last. In the following 
 * program FormatException and Overflow Exceptoin
 * are both more specific than the Exception type. 
 * As a result their catch blocks must be coded before
 * the Exception type. You would get a build error
 * when you try to compile the projekt. This is because
 * the catach blocks are evaluated in sequence.
 * 
 * Author: Salar Asker Zada                      
 *************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TryCatchSpecificException
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double monthlyInvestment = 0;
            try
            {
                monthlyInvestment = double.Parse(tbxMonthlyInvestment.Text);
                double yearlyIntrestRate = double.Parse(tbxYearlyInterestRate.Text);
                int noOfYears = int.Parse(tbxNumberOfYears.Text);
                double monthlyInterestRate = yearlyIntrestRate / 12 / 100;
                int months = noOfYears * 12;
                double futureValue = 0;

                for (int i = 0; i < months; i++)
                {
                    futureValue = ((futureValue + monthlyInvestment)
                        * (1 + monthlyInterestRate));
                }

                tbxFutureValue.Text = Math.Round(futureValue, 2).ToString("c");
            }
            catch (FormatException)
            {
                MessageBox.Show(
                    "A format exception har occured. Please check all entries", 
                    "Entry Error"); 
            }
            catch (OverflowException)
            {
                MessageBox.Show(
                    "A overflow exception har occured. Please enter smaller value",
                    "Entry Error");
            }
            catch (Exception ex)//Exception class object
            {
                //calling methods and properties using the object
                string exType = ex.GetType().ToString();
                string exMessage = ex.Message.ToString();
                MessageBox.Show(exType + "\n" + exMessage, "Exception informatoin");
            }
            finally
            {
                //This code runs whether or not an exception occurs
                //FreeSystemResources();
            }

            
        }
    }
}
